import { db } from "./db";
import {
  users, payments, dailyScores,
  type User, type InsertUser,
  type Payment, type InsertPayment,
  type LeaderboardEntry
} from "../shared/schema";
import { eq, and, desc, sql } from "drizzle-orm";

export interface IStorage {
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  recordPayment(payment: InsertPayment): Promise<Payment>;
  getPayments(walletAddress: string): Promise<Payment[]>;
  getDailyPaymentTotal(dayIndex: number): Promise<string>;
  submitScore(walletAddress: string, score: number, dayIndex: number): Promise<boolean>;
  getLeaderboard(dayIndex: number): Promise<LeaderboardEntry[]>;
}

export class DatabaseStorage implements IStorage {
  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async recordPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db.insert(payments).values(insertPayment).returning();
    return payment;
  }

  async getPayments(walletAddress: string): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(eq(payments.walletAddress, walletAddress))
      .orderBy(desc(payments.createdAt));
  }

  async getDailyPaymentTotal(dayIndex: number): Promise<string> {
    const result = await db.select({
      total: sql<string>`COALESCE(SUM(CAST(${payments.amount} AS NUMERIC)), 0)`,
    })
    .from(payments)
    .where(eq(payments.dayIndex, dayIndex));
    return result[0]?.total || "0";
  }

  async submitScore(walletAddress: string, score: number, dayIndex: number): Promise<boolean> {
    const [existing] = await db.select()
      .from(dailyScores)
      .where(and(
        eq(dailyScores.walletAddress, walletAddress),
        eq(dailyScores.dayIndex, dayIndex)
      ));

    if (existing) {
      if (score > existing.score) {
        await db.update(dailyScores)
          .set({
            score: score,
            gamesPlayed: sql`${dailyScores.gamesPlayed} + 1`,
            updatedAt: new Date()
          })
          .where(eq(dailyScores.id, existing.id));
        return true;
      } else {
        await db.update(dailyScores)
          .set({
            gamesPlayed: sql`${dailyScores.gamesPlayed} + 1`,
            updatedAt: new Date()
          })
          .where(eq(dailyScores.id, existing.id));
        return false;
      }
    } else {
      await db.insert(dailyScores).values({
        walletAddress,
        dayIndex,
        score,
        gamesPlayed: 1
      });
      return true;
    }
  }

  async getLeaderboard(dayIndex: number): Promise<LeaderboardEntry[]> {
    const results = await db.select({
      walletAddress: dailyScores.walletAddress,
      username: users.username,
      score: dailyScores.score,
      gamesPlayed: dailyScores.gamesPlayed
    })
    .from(dailyScores)
    .leftJoin(users, eq(dailyScores.walletAddress, users.walletAddress))
    .where(eq(dailyScores.dayIndex, dayIndex))
    .orderBy(desc(dailyScores.score))
    .limit(50);

    return results.map((r, index) => ({
      ...r,
      rank: index + 1
    }));
  }
}

export const storage = new DatabaseStorage();
