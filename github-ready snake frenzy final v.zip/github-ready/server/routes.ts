import type { Express } from "express";
import { createServer, type Server } from "node:http";
import { storage } from "./storage";
import { api } from "../shared/routes";
import { z } from "zod";

const TOKEN_CONTRACT = "0xc55395a7B5B4AbCF7DfF41B8300BED1e1354Ab07";
const TREASURY_ADDRESS = "0x4c026d5d6a7fe1b2e2b28b916ef2016f6058f7b4";
const GAME_COST_USD = 0.05;
const CHAIN_ID = 8453;

async function fetchTokenPrice(): Promise<{ priceUsd: number }> {
  try {
    const response = await fetch(
      `https://api.dexscreener.com/latest/dex/tokens/${TOKEN_CONTRACT}`
    );
    const data = await response.json() as any;
    if (data.pairs && data.pairs.length > 0) {
      return { priceUsd: parseFloat(data.pairs[0].priceUsd) };
    }
  } catch (e) {
    console.error("Failed to fetch price:", e);
  }
  return { priceUsd: 0.000001 };
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.get(api.config.get.path, (_req, res) => {
    res.json({
      treasuryAddress: TREASURY_ADDRESS,
      tokenContract: TOKEN_CONTRACT,
      chainId: CHAIN_ID,
      gameCostUsd: GAME_COST_USD,
    });
  });

  app.get(api.price.get.path, async (_req, res) => {
    const { priceUsd } = await fetchTokenPrice();
    const tokensForGame = priceUsd > 0 ? GAME_COST_USD / priceUsd : 0;
    res.json({
      priceUsd,
      tokensForGame,
      updatedAt: Date.now(),
    });
  });

  app.get(api.jackpot.get.path, async (_req, res) => {
    const now = new Date();
    const dayIndex = Math.floor(now.getTime() / 86400000);
    const totalPayments = await storage.getDailyPaymentTotal(dayIndex);
    const jackpotPool = (parseFloat(totalPayments) * 0.25).toString();
    const leaderboard = await storage.getLeaderboard(dayIndex);
    const gamesPlayedToday = leaderboard.reduce((sum, e) => sum + e.gamesPlayed, 0);
    res.json({ dayIndex, totalPayments, jackpotPool, gamesPlayedToday });
  });

  app.post(api.payments.record.path, async (req, res) => {
    try {
      const input = api.payments.record.input.parse(req.body);
      const normalizedWallet = input.walletAddress.toLowerCase();

      let user = await storage.getUserByWallet(normalizedWallet);
      if (!user) {
        user = await storage.createUser({ walletAddress: normalizedWallet });
      }

      const now = new Date();
      const dayIndex = Math.floor(now.getTime() / 86400000);

      const payment = await storage.recordPayment({
        walletAddress: normalizedWallet,
        txHash: input.txHash,
        amount: input.amount,
        dayIndex: dayIndex,
      });

      res.json({ success: true, paymentId: payment.id });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        console.error("Payment error:", err);
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.get(api.payments.list.path, async (req, res) => {
    const walletAddress = req.params.walletAddress as string;
    const payments = await storage.getPayments(walletAddress);
    res.json(
      payments.map((p) => ({
        txHash: p.txHash,
        amount: p.amount,
        createdAt: p.createdAt?.toISOString() || "",
        confirmed: p.confirmed || false,
      }))
    );
  });

  app.post(api.scores.submit.path, async (req, res) => {
    try {
      const input = api.scores.submit.input.parse(req.body);
      const now = new Date();
      const dayIndex = Math.floor(now.getTime() / 86400000);
      const isHigh = await storage.submitScore(
        input.walletAddress.toLowerCase(),
        input.score,
        dayIndex
      );
      res.json({ success: true, newHighScore: isHigh });
    } catch (err) {
      console.error("Score submit error:", err);
      res.status(500).json({ message: "Failed to submit score" });
    }
  });

  app.get(api.scores.leaderboard.path, async (req, res) => {
    const queryDayIndex = req.query.dayIndex
      ? parseInt(req.query.dayIndex as string)
      : undefined;
    const now = new Date();
    const currentDayIndex = Math.floor(now.getTime() / 86400000);
    const targetDay =
      queryDayIndex !== undefined ? queryDayIndex : currentDayIndex;

    const entries = await storage.getLeaderboard(targetDay);
    res.json({ dayIndex: targetDay, entries });
  });

  app.get("/.well-known/farcaster.json", (req, res) => {
    const host =
      (req.headers["x-forwarded-host"] as string) ||
      req.headers.host ||
      "localhost:5000";
    const proto =
      ((req.headers["x-forwarded-proto"] as string) || req.protocol || "https")
        .split(",")[0]
        .trim();
    const appUrl = `${proto}://${host}`;

    res.json({
      frame: {
        name: "Snake Frenzy",
        tags: ["game", "arcade", "crypto", "base", "snkfrz"],
        homeUrl: appUrl,
        iconUrl: `${appUrl}/logo.png`,
        version: "1",
        imageUrl: `${appUrl}/preview.png`,
        subtitle: "Play-to-earn Snake on Base",
        webhookUrl: `${appUrl}/api/webhook`,
        buttonTitle: "Start Biting",
        description: "Pay-to-play 3D snake game on Base. Feed the snake, climb the leaderboard, and win the daily SNKFRZ token jackpot",
        splashImageUrl: `${appUrl}/splash.png`,
        primaryCategory: "games",
        splashBackgroundColor: "#0a0a0f",
      },
      accountAssociation: {
        header: "eyJmaWQiOjI3NjU2MiwidHlwZSI6ImF1dGgiLCJrZXkiOiIweDQ1OGE1MTFkYjVDN2MxNTMxMTQxZUVEMDkyN2RiOGM0NmUxY2MzYUUifQ",
        payload: "eyJkb21haW4iOiJmcmVuenktdmF1bHQucmVwbGl0LmFwcCJ9",
        signature: "AjvlDBqzc1EJ4W4wrBrDP5JpheNklnSSzqL2VjX/w3sWihHiKsg+UfM9BB7Lgt8+49gDydXMIiwj4SrmGc6FsRw=",
      },
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
