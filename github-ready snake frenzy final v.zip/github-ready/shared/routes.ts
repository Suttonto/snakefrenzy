import { z } from "zod";

export const api = {
  config: {
    get: {
      method: "GET" as const,
      path: "/api/config",
    },
  },
  price: {
    get: {
      method: "GET" as const,
      path: "/api/price",
    },
  },
  payments: {
    record: {
      method: "POST" as const,
      path: "/api/payments",
      input: z.object({
        txHash: z.string(),
        walletAddress: z.string(),
        amount: z.string(),
      }),
    },
    list: {
      method: "GET" as const,
      path: "/api/payments/:walletAddress",
    },
  },
  jackpot: {
    get: {
      method: "GET" as const,
      path: "/api/jackpot",
    },
  },
  scores: {
    submit: {
      method: "POST" as const,
      path: "/api/scores",
      input: z.object({
        walletAddress: z.string(),
        score: z.number(),
      }),
    },
    leaderboard: {
      method: "GET" as const,
      path: "/api/scores/leaderboard",
    },
  },
};
