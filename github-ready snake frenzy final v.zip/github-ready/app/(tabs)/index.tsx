import { useEffect } from "react";
import { StyleSheet, View, Platform, ActivityIndicator, Text } from "react-native";
import { WebView } from "react-native-webview";
import { getApiUrl } from "@/lib/query-client";

export default function GameScreen() {
  const backendUrl = (() => {
    try {
      return getApiUrl();
    } catch {
      return "http://localhost:5000";
    }
  })();

  useEffect(() => {
    if (Platform.OS === "web") {
      window.location.href = backendUrl;
    }
  }, []);

  if (Platform.OS === "web") {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#00ff88" />
        <Text style={styles.loadingText}>Loading Snake Frenzy...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <WebView
        source={{ uri: backendUrl }}
        style={styles.webview}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        renderLoading={() => (
          <View style={styles.loading}>
            <ActivityIndicator size="large" color="#00ff88" />
            <Text style={styles.loadingText}>Loading Snake Frenzy...</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0a0a0f",
  },
  webview: {
    flex: 1,
    backgroundColor: "#0a0a0f",
  },
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#0a0a0f",
  },
  loadingText: {
    color: "#00ff88",
    fontSize: 16,
    marginTop: 12,
    fontWeight: "600",
  },
});
