# Snake Frenzy — Pay-to-Play Game on Base Chain

A complete, production-ready template for building **token-gated games** on the Base blockchain with Farcaster mini app support. Players pay $0.05 USD per game in ERC-20 tokens. Includes daily leaderboard, jackpot system, wallet connection, and native Farcaster swap integration.

Use this repo as a blueprint to build your own pay-to-play game — swap out the snake game for any game you want while keeping the entire payment, wallet, leaderboard, and Farcaster infrastructure intact.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    Express Server (:5000)                │
│                                                         │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐ │
│  │  Landing     │  │  REST API    │  │  Farcaster     │ │
│  │  Page (HTML) │  │  /api/*      │  │  Manifest      │ │
│  │             │  │              │  │  /.well-known/ │ │
│  └──────┬──────┘  └──────┬───────┘  └────────────────┘ │
│         │                │                              │
│  ┌──────┴──────────────┴─────────┐                     │
│  │         Game Page              │                     │
│  │  ┌───────────┬──────────────┐ │                     │
│  │  │  Wallet   │  Payment     │ │                     │
│  │  │  Connect  │  Flow        │ │                     │
│  │  ├───────────┼──────────────┤ │                     │
│  │  │  THE GAME │  Leaderboard │ │                     │
│  │  │  (Canvas) │  + Jackpot   │ │                     │
│  │  └───────────┴──────────────┘ │                     │
│  └───────────────────────────────┘                     │
│                    │                                    │
│              ┌─────┴──────┐                             │
│              │ PostgreSQL │                             │
│              │ (Drizzle)  │                             │
│              └────────────┘                             │
└─────────────────────────────────────────────────────────┘
```

**Stack:** Express + TypeScript backend, single-page HTML/CSS/JS frontend, PostgreSQL via Drizzle ORM, ethers.js for blockchain, Three.js for 3D rendering.

---

## File Structure

```
├── server/
│   ├── index.ts                  # Express server entry point, CORS, Farcaster meta tag injection
│   ├── routes.ts                 # All API endpoints + Farcaster manifest (/.well-known/farcaster.json)
│   ├── storage.ts                # Database queries (users, payments, scores, leaderboard)
│   ├── db.ts                     # Drizzle database connection
│   └── templates/
│       └── landing-page.html     # THE ENTIRE GAME — wallet, payments, game, UI (single file)
├── shared/
│   ├── schema.ts                 # Database tables: users, payments, daily_scores
│   └── routes.ts                 # API route definitions with Zod validation
├── public/
│   ├── logo.png                  # App icon (used in Farcaster manifest)
│   ├── preview.png               # OG image / Farcaster preview image
│   └── splash.png                # Farcaster splash screen
├── package.json
└── drizzle.config.ts
```

---

## How the Payment Flow Works

This is the core monetization system. It works identically regardless of what game is behind the paywall.

### Step-by-Step Flow

1. **User connects wallet** (MetaMask or Farcaster built-in wallet)
2. **User taps "INSERT COIN"** — opens payment modal
3. **Backend fetches live token price** from DexScreener API (`GET /api/price`)
4. **Frontend calculates tokens needed** — `$0.05 / token_price_usd`
5. **Frontend checks user's token balance** via Base RPC (`balanceOf()`)
6. **If insufficient balance:**
   - Farcaster: Shows "Buy Tokens" button that opens native swap UI via `sdk.actions.swapToken()`
   - Browser: Shows "Buy on Uniswap" link
7. **If sufficient balance:** Shows "INSERT COIN" button
8. **User approves ERC-20 transfer** — `approve()` then `transfer()` to treasury
9. **Frontend sends tx hash to backend** (`POST /api/payments`)
10. **Backend records payment** in database with `dayIndex` for daily tracking
11. **Game starts**

### Key Constants (in `server/routes.ts`)

```typescript
const TOKEN_CONTRACT = "0xc55395a7B5B4AbCF7DfF41B8300BED1e1354Ab07";  // Your ERC-20 token
const TREASURY_ADDRESS = "0x4c026d5d6a7fe1b2e2b28b916ef2016f6058f7b4";  // Where payments go
const GAME_COST_USD = 0.05;  // Cost per game in USD
const CHAIN_ID = 8453;  // Base chain
```

These same constants are also defined in the frontend (`landing-page.html` lines ~385-390).

---

## API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/api/config` | Returns treasury address, token contract, chain ID, game cost |
| `GET` | `/api/price` | Live token price from DexScreener + tokens needed per game |
| `POST` | `/api/payments` | Record a payment (txHash, walletAddress, amount) |
| `GET` | `/api/payments/:walletAddress` | List payment history for a wallet |
| `POST` | `/api/scores` | Submit a game score (walletAddress, score) |
| `GET` | `/api/scores/leaderboard` | Daily leaderboard (top 50 by score) |
| `GET` | `/api/jackpot` | Daily jackpot pool (25% of all payments that day) |
| `GET` | `/.well-known/farcaster.json` | Farcaster mini app manifest |

---

## Database Schema

Three tables in PostgreSQL (via Drizzle ORM):

```
users
├── id (serial, PK)
├── walletAddress (text, unique)
├── username (text, nullable)
├── createdAt (timestamp)
└── lastLoginAt (timestamp)

payments
├── id (serial, PK)
├── walletAddress (text)
├── txHash (text, unique)
├── amount (text — token amount as string for precision)
├── dayIndex (integer — days since epoch, for daily grouping)
├── confirmed (boolean)
└── createdAt (timestamp)

daily_scores
├── id (serial, PK)
├── walletAddress (text)
├── dayIndex (integer)
├── score (integer — highest score that day)
├── gamesPlayed (integer)
├── createdAt (timestamp)
└── updatedAt (timestamp)
└── UNIQUE INDEX on (walletAddress, dayIndex)
```

The `dayIndex` system (`Math.floor(Date.now() / 86400000)`) groups everything by UTC day for leaderboard resets and jackpot calculation.

---

## Farcaster Integration

This app works as a **Farcaster Mini App** (formerly "Frames v2"). Here's everything involved:

### 1. Manifest (`/.well-known/farcaster.json`)

Served dynamically from `server/routes.ts`. Contains:
- App name, description, icon, preview image, splash screen
- `accountAssociation` — cryptographic proof linking your Farcaster account to this domain
- **You must regenerate `accountAssociation`** for your own domain and FID

### 2. Meta Tags (injected by `server/index.ts`)

The server dynamically injects `fc:miniapp` and `fc:frame` meta tags into the HTML:

```html
<meta name="fc:miniapp" content='{"version":"1","imageUrl":"...","button":{"title":"Start Biting","action":{"type":"launch_miniapp",...}}}' />
<meta name="fc:frame" content='{"version":"1","imageUrl":"...","button":{"title":"Start Biting","action":{"type":"launch_frame",...}}}' />
```

These are generated in `server/index.ts` → `serveLandingPage()` using the `__FC_MINIAPP_META__` and `__FC_FRAME_META__` placeholder replacement.

### 3. SDK Integration (in `landing-page.html`)

```html
<script src="https://cdn.jsdelivr.net/npm/@farcaster/miniapp-sdk/dist/index.min.js"></script>
```

The frontend uses the Farcaster MiniApp SDK for:
- **Auto-detect Farcaster context** — `window.miniapp.isInMiniApp()`
- **Get wallet provider** — `sdk.wallet.getEthereumProvider()` (stored as `rawEthProvider`)
- **Native token swap** — `sdk.actions.swapToken({ buyToken: TOKEN_CONTRACT })` when balance is insufficient
- **Signal ready** — `sdk.actions.ready()` to dismiss Farcaster loading screen

### 4. Account Association

The `accountAssociation` in the manifest proves domain ownership. It contains:
- `header` — Base64-encoded JSON with your FID and signing key
- `payload` — Base64-encoded JSON with your domain (no trailing slash, no protocol)
- `signature` — Ed25519 signature

**To generate your own:** Use the [Farcaster Mini App Manifest Tool](https://mini-app-manifest.farcaster.xyz/) or sign it programmatically with your custody address.

---

## Wallet Connection

The app supports two wallet paths:

### Farcaster Wallet (inside Warpcast)
1. Detected via `window.miniapp.isInMiniApp()`
2. Provider obtained via `sdk.wallet.getEthereumProvider()`
3. Stored as `rawEthProvider` for direct `eth_sendTransaction` calls
4. Chain switching: `wallet_switchEthereumChain` with chainId `0x2105` (Base)

### MetaMask / Browser Wallet
1. Detected via `window.ethereum`
2. Uses standard `eth_requestAccounts`
3. Chain switching to Base with automatic `wallet_addEthereumChain` fallback

### Important Implementation Details

- **Balance checks use a public RPC** (`https://mainnet.base.org`) — NOT the wallet provider. Using the wallet provider for `balanceOf` calls can hang in Farcaster.
- **Transactions use raw `eth_sendTransaction`** — NOT ethers.js contract methods. This avoids "missing revert data" errors from contract simulation in Farcaster's provider.
- **Chain ID is explicitly set** in every transaction object as `0x2105` to ensure Base chain.

---

## How to Replace the Game

The game logic is entirely self-contained in `server/templates/landing-page.html`. Here's how to swap it:

### What to Keep (DO NOT MODIFY)

These sections handle payments, wallet, and infrastructure — they work with any game:

| Section in landing-page.html | Lines (approx) | Purpose |
|------------------------------|-----------------|---------|
| `<head>` meta tags | 1-14 | Farcaster meta, OG tags |
| CSS variables + layout | 15-280 | Theme, modal styles, layout |
| Menu screen HTML | 285-330 | Connect wallet, leaderboard, jackpot display |
| Payment modal HTML | 350-370 | Token payment UI |
| Game over screen HTML | 335-350 | Score display, share button, play again |
| Wallet connection JS | `// ===== WALLET =====` | All wallet logic |
| Payment flow JS | `// ===== PAYMENT =====` | Token transfer, balance check, swap |
| UI rendering JS | `// ===== UI RENDERING =====` | Leaderboard rendering |
| Screen management JS | `// ===== SCREENS =====` | Screen switching |
| Share JS | `// ===== SHARE =====` | Share to Farcaster |

### What to Replace (YOUR GAME)

Replace these sections with your own game:

| Section | Lines (approx) | What it does |
|---------|-----------------|-------------|
| `// ===== 3D GAME STATE =====` | ~421-440 | Game variables (snake array, direction, speed, score) |
| `// ===== 3D HELPERS =====` | ~882-1080 | Three.js scene setup, camera, lighting, grid |
| `// ===== 3D SNAKE RENDERING =====` | ~1082-1250 | Snake/food mesh creation and animation |
| `threeRenderLoop()` | ~1250-1280 | Animation frame loop |
| `// ===== 3D SNAKE GAME =====` | ~1284-1420 | `startGame()`, `gameTick()`, `endGame()`, collision, scoring |
| `// ===== CONTROLS =====` | ~1435-1500 | Keyboard + touch/swipe input handling |
| Game screen HTML (`#gameScreen`) | ~330-335 | Canvas container, HUD overlay |

### Integration Points Your Game Must Implement

Your replacement game must call these functions at the right moments:

```javascript
// 1. START — Called when payment is confirmed. Initialize your game here.
function startGame() {
    showScreen('gameScreen');  // Switch to game view
    // ... set up your game ...
    score = 0;
    gameRunning = true;
}

// 2. SCORING — Update the score variable and HUD during gameplay
score += points;
document.getElementById('hudScore').textContent = score;

// 3. END — Called when game is over. This triggers score submission + game over screen.
function endGame() {
    gameRunning = false;
    // Store final stats
    lastScore = { score: score, length: snake.length, combo: maxCombo };
    // Submit score to backend (if wallet connected)
    if (walletAddress) {
        submitScore(score);
    }
    // Show results
    document.getElementById('finalScore').textContent = score;
    // Switch to game over screen
    showScreen('gameoverScreen');
    fetchLeaderboard();
}
```

### Variables Your Game Can Use

These are already defined and managed by the payment/wallet system:

```javascript
walletAddress    // Connected wallet address (lowercase) or null
score            // Current game score (integer)
gameRunning      // Boolean — is game active
lastScore        // Object with final stats shown on game over screen
```

### HTML Elements Your Game Should Use

```html
<!-- Your game renders inside this container -->
<div id="gameScreen" class="screen">
    <div id="gameContainer">
        <!-- Your canvas or game elements go here -->
    </div>
    <!-- HUD overlay -->
    <div id="hud">
        <div id="hudScore">0</div>
    </div>
</div>

<!-- Game over screen reads from these elements -->
<span id="finalScore">0</span>    <!-- Final score display -->
```

### Step-by-Step Replacement Guide

1. **Delete** all code between `// ===== 3D GAME STATE =====` and `// ===== SHARE =====`
2. **Delete** the Three.js CDN script tag: `<script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"></script>`
3. **Keep** the `#gameScreen` div but replace its inner content with your game's HTML
4. **Add** your game's JS where the deleted code was
5. **Implement** `startGame()` and `endGame()` following the interface above
6. **Update** the HUD element IDs if your game uses different score displays
7. **Update** `lastScore` object in `endGame()` — the game over screen reads from this

### Example: Minimal Game Replacement

```javascript
// ===== YOUR GAME =====
let gameInterval = null;

function startGame() {
    showScreen('gameScreen');
    score = 0;
    gameRunning = true;
    document.getElementById('hudScore').textContent = '0';

    // Your game setup here
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');

    gameInterval = setInterval(function() {
        if (!gameRunning) return;
        // Your game loop here
        // Update score, check collisions, render, etc.
    }, 16);
}

function endGame() {
    gameRunning = false;
    if (gameInterval) { clearInterval(gameInterval); gameInterval = null; }
    lastScore = { score: score };
    if (walletAddress) submitScore(score);
    document.getElementById('finalScore').textContent = score;
    setTimeout(function() {
        showScreen('gameoverScreen');
        fetchLeaderboard();
    }, 500);
}
```

---

## Customization Checklist

When building your own version, update these:

### Required Changes

- [ ] **Token contract** — Replace `TOKEN_CONTRACT` in both `server/routes.ts` AND `landing-page.html`
- [ ] **Treasury address** — Replace `TREASURY_ADDRESS` in both files
- [ ] **Game cost** — Change `GAME_COST_USD` in `server/routes.ts` (default: $0.05)
- [ ] **Chain ID** — Change `CHAIN_ID` if not using Base (8453)
- [ ] **Farcaster manifest** — Update app name, description, images in `server/routes.ts` → `/.well-known/farcaster.json`
- [ ] **Account association** — Regenerate for your domain + FID
- [ ] **Meta tags** — Update `fc:miniapp` and `fc:frame` button titles and app name in `server/index.ts` → `serveLandingPage()`
- [ ] **OG tags** — Update title, description in `landing-page.html` `<head>`
- [ ] **Images** — Replace `public/logo.png`, `public/preview.png`, `public/splash.png`
- [ ] **The game itself** — Replace the snake game code in `landing-page.html`

### Optional Changes

- [ ] **Jackpot percentage** — Change the `0.25` multiplier in `server/routes.ts` → jackpot endpoint
- [ ] **Leaderboard size** — Change `.limit(50)` in `server/storage.ts`
- [ ] **Game speed / difficulty** — Adjust `INITIAL_SPEED`, `MIN_SPEED` constants
- [ ] **Color theme** — Update CSS variables in `:root` block
- [ ] **Uniswap URL** — Update the fallback swap URL for non-Farcaster users
- [ ] **DexScreener pair** — Price fetching uses token contract; works automatically for any listed token

---

## Environment Variables

```
DATABASE_URL=postgresql://...    # PostgreSQL connection string
```

No API keys needed — price data comes from DexScreener's public API, and wallet interactions happen client-side.

---

## Running Locally

```bash
npm install
npm run db:push          # Create database tables
npm run server:dev       # Start Express server on :5000
```

Visit `http://localhost:5000` to see the app.

---

## Deployment

Built for Replit deployment but works anywhere with Node.js and PostgreSQL:

```bash
npm run server:build     # Bundle server with esbuild
npm run server:prod      # Run production server
```

The server binds to `0.0.0.0:5000` and serves everything (game page + API + static assets) from a single process.
